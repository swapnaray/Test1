import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.AfterMethod;

public class LoginTest {
  @Test
  public void f() {
	  System.out.println(" Test Hello Word");
  }
  @BeforeMethod
  public void beforeMethod() {
	  System.out.println("Before Hello Word");
  }

  @AfterMethod
  public void afterMethod() {
	  System.out.println("After Hello Word");
	  System.out.println(System.getProperty("user.dir"));
	  System.out.println();
	  System.out.println();
	  System.out.println();
  }

}
